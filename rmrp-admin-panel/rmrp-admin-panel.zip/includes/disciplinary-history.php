<?php
if (!defined('ABSPATH')) exit;

function rmrp_get_user_disciplinary_actions($user_id) {
    global $wpdb;
    $table = $wpdb->prefix . 'rmrp_disciplinary_actions';

    $results = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM {$table} WHERE user_id = %d ORDER BY date_issued DESC", $user_id)
    );

    return $results ?: [];
}

function rmrp_render_disciplinary_tab_content() {
    $user_id = bp_displayed_user_id();
    $actions = rmrp_get_user_disciplinary_actions($user_id);

    echo '<div class="rmrp-disciplinary-history">';
    echo '<h3>История дисциплинарных взысканий</h3>';

    if (empty($actions)) {
        echo '<p>Нет данных о взысканиях.</p>';
    } else {
        echo '<ul class="disciplinary-list" style="list-style: none; padding-left: 0;">';
        foreach ($actions as $action) {
            $type_label = ($action->type === 'warning') ? 'Предупреждение' : 'Выговор';
            $color = ($action->type === 'warning') ? '#f1c40f' : '#e67e22';
            echo '<li style="margin-bottom: 10px; padding: 10px; background: #f9f9f9; border-left: 5px solid ' . esc_attr($color) . ';">';
            echo '<strong>' . esc_html($type_label) . '</strong><br>';
            echo 'Дата: ' . esc_html(date('d.m.Y H:i', strtotime($action->date_issued))) . '<br>';
            echo 'Причина: ' . esc_html($action->reason) . '<br>';
            echo 'Выдал: ' . esc_html(bp_core_get_user_displayname($action->issued_by)) . '<br>';
            echo '</li>';
        }
        echo '</ul>';
    }

    echo '</div>';
}
