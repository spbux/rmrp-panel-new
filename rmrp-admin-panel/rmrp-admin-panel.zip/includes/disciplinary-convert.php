<?php
if (!defined('ABSPATH')) exit;

add_action('init', function () {
    if (!isset($_POST['rmrp_disciplinary_type'], $_POST['rmrp_disciplinary_target'])) return;

    global $wpdb;
    $table = $wpdb->prefix . 'rmrp_disciplinary';

    $target_id = (int) $_POST['rmrp_disciplinary_target'];

    // Считаем предупреждения
    $warnings = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id = %d AND type = 'warning' ORDER BY date_issued ASC",
        $target_id
    ));

    if (count($warnings) >= 2) {
        // Удалим 2 старейших предупреждения
        $wpdb->delete($table, ['id' => $warnings[0]->id]);
        $wpdb->delete($table, ['id' => $warnings[1]->id]);

        // Добавим выговор
        $wpdb->insert($table, [
            'user_id' => $target_id,
            'issued_by' => get_current_user_id(),
            'type' => 'reprimand',
            'reason' => 'Автоматическая замена двух предупреждений',
            'date_issued' => current_time('mysql'),
        ]);

        // Нотификация
        bp_notifications_add_notification([
            'user_id' => $target_id,
            'item_id' => 1,
            'component_name' => 'activity',
            'component_action' => 'reprimand_issued',
            'date_notified' => bp_core_current_time(),
            'is_new' => 1,
        ]);
    }
});
