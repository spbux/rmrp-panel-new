<?php
if (!defined('ABSPATH')) exit;

add_action('init', function () {
    if (!is_user_logged_in()) return;

    if (!isset($_POST['rmrp_disciplinary_type'], $_POST['rmrp_disciplinary_reason'], $_POST['rmrp_disciplinary_target'])) return;

    $target_id = (int) $_POST['rmrp_disciplinary_target'];
    $issued_by = get_current_user_id();
    $type = sanitize_text_field($_POST['rmrp_disciplinary_type']);
    $reason = sanitize_textarea_field($_POST['rmrp_disciplinary_reason']);

    if (!in_array($type, ['warning', 'reprimand'])) return;

    global $wpdb;
    $table = $wpdb->prefix . 'rmrp_disciplinary';

    $wpdb->insert($table, [
        'user_id' => $target_id,
        'issued_by' => $issued_by,
        'type' => $type,
        'reason' => $reason,
        'date_issued' => current_time('mysql'),
    ]);

    // Нотификация
    bp_notifications_add_notification([
        'user_id' => $target_id,
        'item_id' => 1,
        'component_name' => 'activity',
        'component_action' => $type === 'warning' ? 'warning_issued' : 'reprimand_issued',
        'date_notified' => bp_core_current_time(),
        'is_new' => 1,
    ]);

    wp_redirect(bp_core_get_user_domain($target_id));
    exit;
});
